

var start = function() {

  var input = document.getElementById("in").value;

    output("~Le texte RPG~ <br/><br/+>" +
      "Version: 0.1.8 - 04/12/2020 <br/><br/>" +
      "~Jeu terminer~<br>");

    //permet au joueur de mettre un nom 
    var getName = function() {
      player.name = prompt("Salut jeune... quelle est ton nom ?");
    }
    getName();



    var ifPlayerName = function() {
      parent = document.getElementById("container");
      child = document.getElementById("howTo");
  
      parent.removeChild(child);
    }
    ifPlayerName();
  };
  
  //permet d'afficher le texte
  var output = function(txt) {
    document.getElementById("game").innerHTML = txt;
  };
  
  add_output = document.getElementById("game");
  
  //matien des ongel 
  var first_ow_visit = 0;
  var unlocked_battle = 0;
  
  //<==== INFORMATION DU JOUEUR =====>
  var player = {
    name: "Unknown",
    
    location: overWorld,
  
    health: 100,
  
    strength: 2,
  
    money: 0,
  
    abilities: [],
    
    hasHealth: function () {
      if(this.health < 0){
        this.health = 0;
      }
    }
  };
  
  //<==== INFORMATION DU JOUEUR =====>
  
  //<===== NOUVEAU MONDE ======>
  var overWorld = function() {
    // reset de l'écrant
    var clearUponVisit = function() {
      add_output.innerHTML = "";
    }
    clearUponVisit();
  
    // premier dialogue 
    var checkFirstVisit = function() {
      if (first_ow_visit === 0) {
        player.money += 15;
        output("Tu te reveille au milieux des buisson<br/> " +
          "... <br/> " +
          "Tu est prit d'une folie meurtriere et tu prend t'on argent de poche pour tuer des gens<br/> Argent de poche : 15 d'or<br><br>");
  
        first_ow_visit += 1;
  
      }
    }
    checkFirstVisit();
  
    
    var displayHeaderText = function() {
      add_output.innerHTML += "<br/>";
    }
    displayHeaderText();
  
    //<--- CREE EVENT ----->
    randEvent = function() {
      var doge = Math.floor(Math.random() * 100);
      return doge;
    };
    var randEvent = randEvent();
  
    if (first_ow_visit == 1) {
      add_output.innerHTML += "<button style='padding: 2em;' class = 'gameButton' onClick = 'theShop()'>Je me balade dans la foret</button> <br/>";
  
      randEvent = -1;
    }
  
    //<--- CREEE EVENT ----->
  
    // mise en place du shop
    var checkPlayerAbilities = function() {
  
      if (player.abilities.length >= 1 && unlocked_battle === 0) {
        document.getElementById("battleButton").style.display = "inline-block";
  
        add_output.innerHTML += "<br>~Mise a jour~<br>";
        add_output.innerHTML += "<br>Apres avoir acheter un nouvel item. Le tavernier te dit que plus loin il y a un vielle arene<br>";
        add_output.innerHTML += "<br>C'est le moment d'utiliser ton nouvelle abiliter<br>";
        add_output.innerHTML += "<br>Tu inscrit l'arene sur ta carte<br>";
        unlocked_battle += 1;
      }
    }
    checkPlayerAbilities();
  
  };
  //<===== NOUVEAU MONDE ======>
  // enemies
  enemies = [
    {
      id: 0,
      name: "Mechant gobelin",
      
      health: 50,
      power: 4,
        
      money: 10,
      strength: 1,
      
      speech: "Kablarrrrr !!"
    },
    {
      id: 1,
      name: "chef goblelin",
      
      health: 120,
      power: 4,
        
      money: 15,
      strength: 3,
      
      speech: "MUDA MUDA MUDA MUDA MUDA"
      
    },
    {
      id: 2,
      name: "Robin des bois",
      
      health: 300,
      power: 4,
        
      money: 25,
      strength: 10,
      
      speech: "Heu t'est qui...?"
    },
    {
      id: 3,
      name: "Seigneur des Yaourts",
      
      health: 100000,
      power: 4,
        
      money: 50,
      strength: 100,
      
      speech: "T'a perdu forcément j'ai pas dev le reste... T-T"
    }
  ];
  
  //<========= BATAILLE ===============>
  
  var battleWorld = function (enemyID) {
      // check vie du joueur 
      player.hasHealth();
    
      var gameScreen = document.getElementById("game");
      gameScreen.innerHTML = "";
          
      // dans une bataille
      if(player.inBattle && enemyID != undefined){
          
          userInBattle(enemyID);
          
      } 
      
      // pas de bataille
      else {
          
          // liste des adversaire 
          var displaySelectScreen = function () {
              gameScreen.innerHTML += "<div id='select'>Choisi ton adversaire</div>";
              gameScreen.innerHTML += "<br /> <div id='opponentList'></div>"
          };
          displaySelectScreen();
          
          // generation de l'opposent 
          var generateOpponents = function () {
              var opponentDiv = document.getElementById("opponentList");
              
              for(var i = 0; i<enemies.length; i++){
                  opponentDiv.innerHTML += "<br /><br /><button style ='padding: 0.5em; 'onClick = 'inBattle("+enemies[i].id+")' class = 'enemyButtons'>"+enemies[i].name+"<br /> Level: "+enemies[i].health/10+"</button>";
              }
          };
          generateOpponents();
          
          inBattle = function (enemyID) {
              player.inBattle = true;
              
              // envoie de l'id
              battleWorld(enemyID);
          
          }
      
          
      };
      
      // Joueur dans la bataille 
      userInBattle = function(enemyID){
          var gameScreen = document.getElementById("game");
          var enemy = enemies[enemyID];
          
          
          //creation de l'écrant de bataille ;
          var displayBattleScreen = function () {
              gameScreen.innerHTML += "_Mortal Conbaaaaat_";
              gameScreen.innerHTML += "<div 'abilitiesAvailable'></div>";
          }
          displayBattleScreen();
          
          //display enemy information
          var displayEnemy = function (id) {
              gameScreen.innerHTML += "<br /><br />Tu conbat : " + enemy.name;
              gameScreen.innerHTML += "<br /><br /><div id = 'enemyHealthBar'></div>";
              gameScreen.innerHTML += "<div id = 'enemyHealth'></div>";
              gameScreen.innerHTML += "<br /> \"" + enemy.speech +"\"";
              
          }
          displayEnemy(enemyID);
          
          //display player information
          var displayPlayerInfo = function () {
              
              var createPlayerHealthBar = function (){
                  gameScreen.innerHTML += "<div id = 'playerHealthBar'></div>";
                  gameScreen.innerHTML += "Ta vie";
                  healthBar = document.getElementById("playerHealthBar");
                  if(player.health > 0){
                  healthBar.style.width = player.health+'%';
                  } else {
                  healthBar.style.width = 1 + '%';
                  }
                  healthBar.style.height = 2+'%';
                  healthBar.style.borderRadius = '15px 15px'
                  
                  healthBar.style.margin = 'auto'
                  
                  healthBar.style.backgroundColor = 'lime';
                  
                  healthBar.style.display = 'block';
                  
              }
              createPlayerHealthBar();
              
              
          };
          displayPlayerInfo();
          
          //creates [abilities buttons]
          var displayAbilitiesAvailable = function(){
          gameScreen = document.getElementById("game");
          gameScreen.innerHTML += "<br />";
            //creates enemy HealthBar here.... idk why
            var createEnemyHealthBar = function (){
              var enemyHealthBar = document.getElementById('enemyHealthBar');
  
              enemyHealthBar.style.height = 2+'%';
              enemyHealthBar.style.borderRadius = '15px 15px'
  
              enemyHealthBar.style.margin = 'auto'
  
              enemyHealthBar.style.backgroundColor = 'red';
  
              enemyHealthBar.style.display = 'block';
            }
            createEnemyHealthBar();
  
          for(var x in player.abilities){
              gameScreen.innerHTML += "  <button style = 'padding: 1em;' onClick = 'updateBattleInformation("+player.abilities[x].id+")'>"+player.abilities[x].name+"<br />Domage: "+player.abilities[x].power+"</button>";
          }
  
          };
          displayAbilitiesAvailable();
          
          healthBar = {
              length: 50,
          }
          
          currentEnemyInfo = {
              health: enemies[enemyID].health,
              max_health: enemies[enemyID].health,
              power: enemies[enemyID].strength,
              
              money: enemies[enemyID].money,
              strength: enemies[enemyID].strength
          }
          
          //[ability buttons] -> gets the ability information;
          updateBattleInformation = function(abilityID){
  
              var playerDamage = abilityList[abilityID].power*(player.strength/10);
              var playerHealth = player.health;
              var max_health = currentEnemyInfo.max_health;
  
              
              var enemyHealth = currentEnemyInfo.health;
              var enemyPower = currentEnemyInfo.power;
              
              enemyHealth -= playerDamage; //updated enemy health
              
              playerHealth -= enemyPower; //updated player health
            
    
              
              //if ENEMY or PLAYER hit 0 health
              if(enemyHealth <= 0){
                  playerWin(currentEnemyInfo.money, currentEnemyInfo.strength);
              } 
              else if (playerHealth <= 0){
                  player.health = 0;
                  playerLost();
              }
              
              
               //<------ ENEMY HEALTH BAR UPDATES -------->
              if(document.getElementById("enemyHealthBar")){
                           document.getElementById("enemyHealthBar").style.maxWidth = '100%';
              document.getElementById("enemyHealthBar").style.width = (enemyHealth/max_health)*100 + "%";
              }
              
              //<------ ENEMY HEALTH BAR UPDATES -------->
              
              
              currentEnemyInfo.health -= playerDamage;
              player.health = playerHealth;
  
              
              //<------ PLAYER HEALTH BAR UPDATES -------->
              if(playerHealth >= 0 && document.getElementById('playerHealthBar')){
              if(playerHealth){
              document.getElementById('playerHealthBar').style.width = player.health + '%';
              } else{
              document.getElementById('playerHealthBar').style.width = 1 + '%';
              }
              }
              //<------ PLAYER HEALTH BAR UPDATES -------->
              
              
              
              
  
  
          }
          
      }
      
      
      //player Win
      
      var playerWin = function (money, strength) {
          document.getElementById("game").innerHTML = "T'a gagner <br /> money: " + money + " - strength: " + strength;
          document.getElementById("game").innerHTML += "<br /> <button style='padding: 2em;' onClick = 'battleWorld()'>Retour</button>";
  
     
          player.money += money;
          player.strength += strength;
          
          player.inBattle = false;
      };
      
      //player Lost
      var playerLost = function () {
          gameScreen = "";
        
          document.getElementById("game").innerHTML = "T'a perdu ...";
          document.getElementById("game").innerHTML += "<br/ ><button style ='padding: 1em;' onClick = 'battleWorld()'>Return</button>";
          
          player.inBattle =false;
          console.log("You lost");
      }
  
  }
  
  //<========= BATTLE FUNCTIONS ===============>
  
  
  //STATS button
  displayStats = function() {
    clearGameWindow();
    var hold = [];
    for (var i = 0; i < player.abilities.length; i++) {
      hold.push(" " + player.abilities[i].name)
    };
  
    output(
      "Nom: " + player.name + "<br/>" +
      "Force: " + player.strength + "<br>" +
      "Or: " + player.money + "<br>" +
      "Vie: " + player.health + "<br />"+
      "Item: " + hold
    );
  };
  
  //clears text from game
  var clearGameWindow = function() {
    document.getElementById("game").innerHTML = "";
  };
  
  // <================== SHOP FUNCTIONS ======================>
  
  //displays shop button
  theShop = function() {
  
    if (first_ow_visit == 1) {
      document.getElementById("shopButton").style.display = "inline-block";
      first_ow_visit += 1;
    
  
    clearGameWindow();
  
    output("Tu tombe sur un teverne au pif...");
  
    add_output.innerHTML += "<br><br>~Mise a jour~";
  
    add_output.innerHTML += ("<br><br> Tu débloque la taverne");
    }
  
  };
  
  // <================== SHOP FUNCTIONS ======================>
  
  var shopWorld = function () {
    //sets player location to ShopWorld
    if(player.location != "theShop"){
      player.location = 'theShop';
    }
    
    //if player location is set to 'shopWorld'  
    console.log(player.location);
    
    var shop = document.getElementById("game");
    var clearShop = function () {shop.innerHTML = "";}
    clearShop();
    
    if(player.location === "theShop"){
      var shop = document.getElementById("game");
      var abilities = abilityList;
          
      //display money
      shop.innerHTML += "<div id ='shopMoney'>Money: "+player.money+"</div><br />";
      
      
      //display each ability available
      for(var x in abilities){
        console.log(player.abilities[x]);
          if(player.abilities[x] == undefined){
          shop.innerHTML += "   <button onclick='purchase("+x+")'style='padding: 0.3em; font-size: 80%; font-family: Monospace;'>"+abilities[x].name+"<br/> Degat: "+abilities[x].power+"<br/>Prix: "+abilities[x].cost+"</button>";
          }
        
      }
      
      
      //make this here so it appears after the ability list
      game.innerHTML += "<br /><div style='font-size: 80%;' id = 'warning'></div>";
      game.innerHTML += "<br /><div style='color: lime;' id='allGood'></div>";
      
      //if player selects an ability -> this runs and if player owns it then it displays results
      purchase = function (id) {
        var warning = document.getElementById('warning');
        var allGood = document.getElementById('allGood');
        var shopMoney = document.getElementById('shopMoney');
        //if player owns more than 1 ability - check and see if player already owns the ability
    
        checkIfOwned = function () {
          for(var x in player.abilities){
            if(player.abilities[x].id == abilityList[id].id){
              //break is here so console doesn't log (can't property undefined);
              return false;
              break;
            }
          }
          return true;
        };
        checkMoney = function () {
          if(player.money < abilityList[id].cost){
            return false;
          }
          return true;
        }
        
        
        if(!checkIfOwned()){
          
          warning.innerHTML = "Heuuu tu l'a deja" + abilityList[id].name;
          allGood.innerHTML = "";
          
        } else if (!checkMoney()) {
          warning.innerHTML = "Trop pauvre DSL" + abilityList[id].name;
          allGood.innerHTML = "";
        }
        else {
          //displays green text
          allGood.innerHTML = "T'a acheter " + abilityList[id].name
      
          //player.money - ability cost
          player.money -= abilityList[id].cost;   
          
          //money updates
          shopMoney.innerHTML = "Or : " + player.money;
        
          //ability bought will push to player abilities
          player.abilities.push(abilityList[id]);
        }
        
        
      }
      
      //creates health Div and everything health display goes here
      var displayHealthShop = function () {
        game.innerHTML += "<div id = 'healthUpdate'>Vie: " + player.health + "</div>";
        game.innerHTML += "<br /><div id = 'healShop'></div>";
        var healthDiv = document.getElementById('healShop');
             
        healthDiv.innerHTML += "<button style = 'font-family: monospace; padding: 0.2em;' onclick='buyHealth(25, 5)'>Soigne: 25 Health<br />Prix: 5 Or</button>";
        
        healthDiv.innerHTML += "   <button style = 'font-family: monospace; padding: 0.2em;' onclick='buyHealth(50, 10)'>Soigne: 50 Health<br />Prix: 10 Or</button>";
        
        healthDiv.innerHTML += "   <button style = 'font-family: monospace; padding: 0.2em;' onclick='buyHealth(100, 30)'>Soigne: 100 Health<br />Prix: 30 Or</button>";
        
           if(player.health >= 100){
          document.getElementById('healShop').style.display = "none";
        }
        
      }
      displayHealthShop();
      
      
      
      
    }
    
    //buy health
    buyHealth = function (health, cost) {
        //check if player has max health, or no health
      //located if(player.location === 'theshop')--> first (if);
      
      //so many IF statements :'( just lazy r/n
      
      //if money and doesn't exceed health -> runs
      if((player.health+health) <= 100 && player.money >= cost){
        
        player.health += health;
        player.money -= cost;
        
        
        document.getElementById('allGood').innerHTML = "Health +" + health;
        document.getElementById('healthUpdate').innerHTML = "Health: " + player.health;
        
      }
      //if player has less money or health
      else {
        //less money
        if(player.money < cost){
          document.getElementById('warning').style.color = 'red';
        document.getElementById('warning').innerHTML = "<br />Or: " + player.money + " - Achete quelque chosse en desous de " + cost + " Or...";
        } 
        //less health
        else{
        document.getElementById('warning').style.color = 'red';
        document.getElementById('warning').innerHTML = "<br />Vie: " + player.health + " - Achete quelque chosse en desous de  " + health + " vie...";
        }
      }
      
      }
    
  };
  
  // <================== SHOP FUNCTIONS ======================>
  
  // <================== ABILITIES ==================>
  var Ability = function(id, name, type, power, stamina_cost, cost, text) {
    this.id = id;
    this.name = name;
    this.type = type;
    this.power = power;
    this.cost = cost;
    this.text = text; 
    
    this.checkStamina = function () {
      if(player.stamina < this.stamina_cost){
        console.log("Pas assez de mana...");
        this.power = 0;
      };
    }
  };
  
  abilityList = [
  //(ID, name, type, power, stamina_cost, cost, text)
  new Ability(0, "Boule de feu", "feu", 10, 3, 15, "CHAUT !!!!! "),
  new Ability(1, "Lance de glace", "glace", 10, 2, 15, "FREEEZ"),
    new Ability(2, "Gand de pierre", "Terre", 12, 5, 20, "*Bruit de chelou*"),
    new Ability(3, "Gand magic", "item", 20, 10, 40, "*Piou*"),
    new Ability(4, "Bout de bois", "item", 40, 1, 45, "*Wabadgak*")
    ];
  // <================== ABILITIES ==================>
  /*
  
  TO DO:
  
    user
      travel [overworld, shop, battle]
        * overworld -
          -as player gets stronger, unlocks new areas.
          -Final area - fight boss (win the game...){user gets a new stat?}
        
        * shop - purchase abilities
          -money count
          -strength count
          
        * battle
          -enemies
            - health
            - abilities
            - strength * abilities
            
          -battle mode
              -conditions(win/lose)
                -if win user gets money + stats
          
      Goal: Functional Javascript Text RPG with HTML (like playable status)
  
  */
  
  document.getElementById('game').style.overflow = 'hidden';